package com.ourdevelops.ourjek.gmap;

import java.io.Serializable;

public class Direction implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -4198690398884769235L;

    public String durationText;
    public String html_instructions;
    public String distanceText;

}
