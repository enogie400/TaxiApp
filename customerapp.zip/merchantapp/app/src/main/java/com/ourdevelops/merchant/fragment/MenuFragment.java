package com.ourdevelops.merchant.fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.ourdevelops.merchant.R;
import com.ourdevelops.merchant.activity.IntroActivity;
import com.ourdevelops.merchant.constants.BaseApp;
import com.ourdevelops.merchant.item.CategoryItem;
import com.ourdevelops.merchant.item.CategoryNonItem;
import com.ourdevelops.merchant.json.AddEditKategoriRequestJson;
import com.ourdevelops.merchant.json.KategoriRequestJson;
import com.ourdevelops.merchant.json.KategoriResponseJson;
import com.ourdevelops.merchant.json.ResponseJson;
import com.ourdevelops.merchant.models.KategoriItemModel;
import com.ourdevelops.merchant.models.KategoriItemNonModel;
import com.ourdevelops.merchant.models.User;
import com.ourdevelops.merchant.utils.Log;
import com.ourdevelops.merchant.utils.api.ServiceGenerator;
import com.ourdevelops.merchant.utils.api.service.MerchantService;

import java.util.List;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MenuFragment extends Fragment {

    private View getView;
    private Context context;
    private Button dialogaddcategory;
    private RecyclerView activecategory, nonactivecategory;
    private TextView itemada, itempromo, itemhabis;
    private ShimmerFrameLayout shimmercaton, shimmercatoff;
    private List<KategoriItemModel> order;
    private List<KategoriItemNonModel> ordernon;
    CategoryItem categoryItem;
    CategoryNonItem categorynonItem;
    LinearLayout llactive, llnonactive;
    RelativeLayout rlnodata;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getView = inflater.inflate(R.layout.fragment_menu, container, false);
        context = getContext();
        dialogaddcategory = getView.findViewById(R.id.buttonaddcategory);
        activecategory = getView.findViewById(R.id.activecategory);
        nonactivecategory = getView.findViewById(R.id.nonactivecategory);
        itemada = getView.findViewById(R.id.itemada);
        itempromo = getView.findViewById(R.id.itempromo);
        itemhabis = getView.findViewById(R.id.itemhabis);
        shimmercaton = getView.findViewById(R.id.shimmercaton);
        shimmercatoff = getView.findViewById(R.id.shimmercatoff);
        rlnodata = getView.findViewById(R.id.rlnodata);
        llactive = getView.findViewById(R.id.llactive);
        llnonactive = getView.findViewById(R.id.llnonactive);


        dialogaddcategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addcategory();
            }
        });

        activecategory.setHasFixedSize(true);
        activecategory.setNestedScrollingEnabled(false);
        activecategory.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));

        nonactivecategory.setHasFixedSize(true);
        nonactivecategory.setNestedScrollingEnabled(false);
        nonactivecategory.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));


        return getView;
    }

    @Override
    public void onResume() {
        super.onResume();
        getdata();
    }

    private void shimmershow() {
        activecategory.setVisibility(View.GONE);
        shimmercaton.startShimmerAnimation();
        shimmercaton.setVisibility(View.VISIBLE);

        nonactivecategory.setVisibility(View.GONE);
        shimmercatoff.startShimmerAnimation();
        shimmercatoff.setVisibility(View.VISIBLE);

    }

    private void shimmertutup() {
        shimmercaton.stopShimmerAnimation();
        activecategory.setVisibility(View.VISIBLE);
        shimmercaton.setVisibility(View.GONE);

        shimmercatoff.stopShimmerAnimation();
        nonactivecategory.setVisibility(View.VISIBLE);
        shimmercatoff.setVisibility(View.GONE);
    }

    private void getdata() {
        shimmershow();
        if (order != null && ordernon != null) {
            order.clear();
            ordernon.clear();
        }
        User loginUser = BaseApp.getInstance(context).getLoginUser();
        MerchantService merchantService = ServiceGenerator.createService(
                MerchantService.class, loginUser.getNoTelepon(), loginUser.getPassword());
        KategoriRequestJson param = new KategoriRequestJson();
        param.setNotelepon(loginUser.getNoTelepon());
        param.setIdmerchant(loginUser.getId_merchant());
        merchantService.kategori(param).enqueue(new Callback<KategoriResponseJson>() {
            @Override
            public void onResponse(Call<KategoriResponseJson> call, Response<KategoriResponseJson> response) {
                if (response.isSuccessful()) {
                    if (response.body().getMessage().equalsIgnoreCase("success")) {
                        order = response.body().getData();
                        ordernon = response.body().getDatanon();
                        shimmertutup();

                        itemada.setText(response.body().getTotalitemactive() + " Item Available");
                        itemhabis.setText(response.body().getTotalitemnonactive() + " Item Out of Stock");
                        itempromo.setText(response.body().getTotalitempromo() + " Item Promo");
                        if (response.body().getData().isEmpty() && response.body().getDatanon().isEmpty()) {
                            rlnodata.setVisibility(View.VISIBLE);
                        } else {
                            rlnodata.setVisibility(View.GONE);
                        }
                        categoryItem = new CategoryItem(context, order, R.layout.item_category);
                        activecategory.setAdapter(categoryItem);
                        if (response.body().getData().isEmpty()) {
                            llactive.setVisibility(View.GONE);
                        } else {
                            ;
                            llactive.setVisibility(View.VISIBLE);
                        }

                        categorynonItem = new CategoryNonItem(context, ordernon, R.layout.item_category);
                        nonactivecategory.setAdapter(categorynonItem);
                        if (response.body().getDatanon().isEmpty()) {
                            llnonactive.setVisibility(View.GONE);
                        } else {
                            llnonactive.setVisibility(View.VISIBLE);
                        }
                    } else {
                        Realm realm = BaseApp.getInstance(getContext()).getRealmInstance();
                        realm.beginTransaction();
                        realm.delete(User.class);
                        realm.commitTransaction();
                        BaseApp.getInstance(getContext()).setLoginUser(null);
                        startActivity(new Intent(getContext(), IntroActivity.class)
                                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                        getActivity().finish();
                    }
                }
            }

            @Override
            public void onFailure(Call<KategoriResponseJson> call, Throwable t) {

            }
        });
    }


    String Switchstring;
    private void addcategory() {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_addcategory);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        ImageView close = (ImageView) dialog.findViewById(R.id.close);
        EditText text = (EditText) dialog.findViewById(R.id.textadd);
        SwitchCompat switchadd = (SwitchCompat) dialog.findViewById(R.id.switchactive);
        Button submit = (Button) dialog.findViewById(R.id.submit);


        switchadd.setChecked(true);
        Switchstring = "1";

        switchadd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        Switchstring = "1";
                    } else {
                        Switchstring = "0";
                    }

                Log.e("switch",Switchstring);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().toString().isEmpty()) {
                    Toast.makeText(context, "Please input Category Name!", Toast.LENGTH_SHORT).show();
                } else {
                    submit.setEnabled(false);
                    submit.setText("Please Wait...");
                    submit.setBackground(context.getResources().getDrawable(R.drawable.button_round_3));
                    User loginUser = BaseApp.getInstance(context).getLoginUser();
                    MerchantService merchantService = ServiceGenerator.createService(
                            MerchantService.class, loginUser.getNoTelepon(), loginUser.getPassword());
                    AddEditKategoriRequestJson param = new AddEditKategoriRequestJson();
                    param.setNotelepon(loginUser.getNoTelepon());
                    param.setId(loginUser.getId_merchant());
                    param.setNamakategori(text.getText().toString());
                    param.setStatus(Switchstring);
                    merchantService.addkategori(param).enqueue(new Callback<ResponseJson>() {
                        @Override
                        public void onResponse(Call<ResponseJson> call, Response<ResponseJson> response) {
                            if (response.isSuccessful()) {
                                if (response.body().getMessage().equalsIgnoreCase("success")) {
                                    getdata();
                                    Toast.makeText(context, "Success!", Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();

                                } else {
                                    submit.setEnabled(true);
                                    Toast.makeText(context, "Error!", Toast.LENGTH_SHORT).show();
                                    submit.setText("Add Category");
                                    submit.setBackground(context.getResources().getDrawable(R.drawable.button_round_1));
                                }
                            }
                        }

                        @Override
                        public void onFailure(Call<ResponseJson> call, Throwable t) {
                            submit.setEnabled(true);
                            Toast.makeText(context, "Error Connection!", Toast.LENGTH_SHORT).show();
                            submit.setText("Add Category");
                            submit.setBackground(context.getResources().getDrawable(R.drawable.button_round_1));

                        }
                    });

                }

            }
        });

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });


        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }
}
