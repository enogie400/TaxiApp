package com.ourdevelops.merchant.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.ourdevelops.merchant.R;

public class ReportsFragment extends Fragment {

    View getView;
    Context context;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getView = inflater.inflate(R.layout.fragment_reports, container, false);
        context = getContext();


        return getView;
    }
}
